"""
auto_process.py — Procesa la cola de chat dentro de Blender.
Timer que cada 0.5s revisa mensajes y los envía al LLM configurado.
Sin procesos externos. Sin mcp_server.py. Sin agent_host.py.
"""
import bpy
import json
import os
import re
import time
import threading
import traceback
import urllib.request
import logging
from datetime import datetime
from . import _axsock as bsock

logger = logging.getLogger("blender-mcp-auto")

_processed_ids = set()
_in_flight = {}
_message_start = {}
_timer_registered = False


def start():
    global _timer_registered
    if _timer_registered:
        return
    bpy.app.timers.register(_tick, first_interval=0.5)
    _timer_registered = True


def _tick():
    try:
        with bsock._chat_lock:
            if not bsock._chat_queue:
                return _check_in_flight()
            messages = list(bsock._chat_queue)

        for msg in messages:
            mid = msg["id"]
            if mid in _processed_ids or mid in _in_flight:
                continue
            _in_flight[mid] = time.time()

            if mid not in _message_start:
                _message_start[mid] = time.time()

            elapsed = time.time() - _message_start[mid]
            text = msg["message"]
            print(f"[AUTO] mid={mid[:8]} text={text[:40]} elapsed={elapsed:.1f}s")

            if _try_auto_start_client():
                _process_with_client(mid, text)
                continue

            if elapsed > 30:
                del _in_flight[mid]
                txt = _diagnose()
                _respond(mid, txt)
                _cleanup(mid)

        return _check_in_flight()

    except Exception as e:
        logger.error(f"auto_process error: {e}")
        return 0.5


def _check_in_flight():
    now = time.time()
    for mid, started in list(_in_flight.items()):
        if now - started > 20:
            _respond(mid, "⏳ DeepSeek sigue pensando... (ya van >20s)", is_status=True)
            return 2.0
        if now - started > 40:
            _respond(mid, "⚠️ DeepSeek tardó más de 40s. Se excedió timeout.", is_status=False)
            _cleanup(mid)
            return 0.5
    return 0.5


def _detect_provider(model_id):
    """Detect provider from model ID string."""
    PROVIDER_ORDER = ["google", "anthropic", "deepseek", "opencode-go", "openrouter"]
    _PROVIDER_API = {
        "deepseek": {"url": "https://api.deepseek.com/v1/models", "auth": True},
        "opencode-go": {"url": "https://opencode.ai/zen/go/v1/models", "auth": True},
        "openrouter": {"url": "https://openrouter.ai/api/v1/models", "auth": False},
        "google": {"url": "https://generativelanguage.googleapis.com/v1beta/models", "auth": True},
        "anthropic": {"url": "https://api.anthropic.com/v1/models", "auth": True},
    }
    for pid in PROVIDER_ORDER:
        if model_id.startswith(pid):
            return pid
    for pid in _PROVIDER_API:
        if pid in model_id:
            return pid
    return "opencode-go"


def _get_api_key(provider):
    """Busca API key en: env vars → opencode auth.json → config cache."""
    env_map = {"opencode-go": "OPENAI_API_KEY", "deepseek": "DEEPSEEK_API_KEY",
               "openrouter": "OPENROUTER_API_KEY", "anthropic": "ANTHROPIC_API_KEY",
               "google": "GOOGLE_API_KEY"}
    key = os.environ.get(env_map.get(provider, ""), "")
    if key:
        return key
    try:
        from .platform_utils import get_opencode_auth_path
        p = get_opencode_auth_path()
        if p.exists():
            auth = json.loads(p.read_text())
            entry = auth.get(provider, {})
            if isinstance(entry, dict) and entry.get("key"):
                return entry["key"]
    except:
        pass
    try:
        from .config_cache import get_provider_config
        return get_provider_config(provider).get("api_key", "")
    except:
        pass
    return ""


_CHAT_URLS = {
    "opencode-go": "https://opencode.ai/zen/go/v1/chat/completions",
    "openai": "https://api.openai.com/v1/chat/completions",
    "deepseek": "https://api.deepseek.com/v1/chat/completions",
    "openrouter": "https://openrouter.ai/api/v1/chat/completions",
    "google": "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
    "anthropic": "https://api.anthropic.com/v1/messages",
    "ollama": "http://localhost:11434/v1/chat/completions",
}

_ANTHROPIC_HEADERS = {
    "anthropic-version": "2023-06-01",
    "content-type": "application/json",
}

SYSTEM_PROMPT = """Eres un asistente integrado en Blender 3D (Blender 4.2, Python API). Genera código Python completo.

REGLAS ESTRICTAS:
- Cada instrucción en UNA sola línea. NO partas asignaciones ni argumentos entre líneas.
- Usa `bpy.context.active_object` para objeto recién creado. NUNCA `bpy.context.object`.
- Para añadir un modifier usa: `obj.modifiers.new(name="...", type='...')`. NO uses `bpy.ops.object.modifier_add`.
- Todo el código en ```python ... ```. Sin explicaciones. Sin texto fuera del bloque.
- Materiales: Principled BSDF con RGBA, sin Specular.
- Termina con `print("OK")`.

Ejemplo correcto:
```python
import bpy
bpy.ops.mesh.primitive_uv_sphere_add(radius=1, location=(0, 0, 0))
s = bpy.context.active_object
s.name = "MiEsfera"
mod = s.modifiers.new(name="Subdiv", type='SUBSURF')
mod.levels = 2
mat = bpy.data.materials.new(name="Mat")
mat.use_nodes = True
mat.node_tree.nodes["Principled BSDF"].inputs[0].default_value = (1, 0, 0, 1)
s.data.materials.append(mat)
print("OK")
```"""


def _exec_code(code):
    ns = {"bpy": bpy, "C": bpy.context, "D": bpy.data, "ops": bpy.ops}
    try:
        compiled = compile(code, "<blender_code>", "exec")
        exec(compiled, ns)
        print("[AUTO] Código ejecutado correctamente")
        return None
    except Exception as e:
        err = f"Error: {e}"
        print(f"[AUTO] {err}")
        return err


def _append_to_log(text, tag="AI"):
    try:
        log_path = os.path.expanduser("~/.config/blender-mcp/chat_log.txt")
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        with open(log_path, "a") as f:
            f.write(f"[{datetime.now().strftime('%H:%M')}] {tag}: {text}\n\n")
    except:
        pass


def _call_llm(url, headers, model, messages):
    body = json.dumps({
        "model": model,
        "messages": messages,
        "max_tokens": 8192,
        "temperature": 0.4,
    }).encode()
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read())


def _call_anthropic(url, headers, api_key, model, messages):
    system = ""
    msgs = []
    for m in messages:
        if m["role"] == "system":
            system += m["content"] + "\n"
        elif m["role"] in ("user", "assistant"):
            msgs.append({"role": m["role"], "content": m["content"]})
    body = json.dumps({
        "model": model,
        "max_tokens": 8192,
        "system": system.strip(),
        "messages": msgs,
        "temperature": 0.4,
    }).encode()
    hdrs = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    req = urllib.request.Request(url, data=body, headers=hdrs, method="POST")
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read())


_VISION_PROVIDERS = {"opencode-go", "openai", "openrouter", "google", "anthropic"}

def _capture_screenshot_b64():
    try:
        from .handlers.analysis import AnalysisHandler
        return AnalysisHandler.cmd_get_screenshot_as_base64()
    except:
        return None

def _process_with_client(mid, text):
    scene = bpy.context.scene
    model = getattr(scene, "aimcp_model", "")
    provider = _detect_provider(model) if model else "opencode-go"
    print(f"[AUTO] provider={provider} model={model}")
    api_key = _get_api_key(provider)
    print(f"[AUTO] api_key={'✅' if api_key else '❌'}")

    if not api_key:
        _respond(mid, "❌ No hay API key para " + provider)
        _cleanup(mid)
        return

    url = _CHAT_URLS.get(provider)
    if not url:
        _respond(mid, f"❌ Provider {provider} no soportado")
        _cleanup(mid)
        return

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
        "User-Agent": "blender-mcp/0.8",
    }

    _respond(mid, "⏳ Pensando...", is_status=True)

    def process():
        print(f"[AUTO] Llamando a {provider} con modelo {model}")
        messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        objs = [o.name for o in bpy.data.objects if hasattr(o, 'name')]
        if objs:
            messages.append({"role": "system", "content": f"Escena actual: {', '.join(objs[:10])}"})

        user_msg = text

        if provider in _VISION_PROVIDERS:
            shot = _capture_screenshot_b64()
            if shot and "base64" in shot:
                user_msg = [
                    {"type": "text", "text": text},
                    {"type": "image_url", "image_url": {"url": f"data:{shot['mime']};base64,{shot['base64']}"}},
                ]

        messages.append({"role": "user", "content": user_msg})

        is_anthropic = provider == "anthropic"
        try:
            if is_anthropic:
                result = _call_anthropic(url, headers, api_key, model, messages)
                content = ""
                for block in result.get("content", []):
                    if block.get("type") == "text":
                        content += block.get("text", "")
            else:
                result = _call_llm(url, headers, model, messages)
                content = result.get("choices", [{}])[0].get("message", {}).get("content", "")
        except urllib.error.HTTPError as e:
            err = e.read().decode()[:200]
            print(f"[AUTO] HTTP Error {e.code}: {err}")
            _respond(mid, f"❌ HTTP {e.code}")
            _cleanup(mid)
            return
        except Exception as e:
            print(f"[AUTO] Error: {traceback.format_exc()}")
            _respond(mid, f"❌ Error: {str(e)[:60]}")
            _cleanup(mid)
            return

        if not content:
            _respond(mid, "⚠️ El modelo no generó respuesta")
            _cleanup(mid)
            return

        print(f"[AUTO] Respuesta recibida ({len(content)} chars)")

        errors = []
        code_blocks = re.findall(r'```python\n(.*?)```', content, re.DOTALL)
        if code_blocks:
            for i, code in enumerate(code_blocks):
                print(f"[AUTO] Ejecutando código ({i+1}/{len(code_blocks)})...")
                err = _exec_code(code)
                if err:
                    errors.append(err)

        if errors:
            content += "\n\n---\n⚠️ Error al ejecutar:\n" + "\n".join(errors)

        _respond(mid, content)
        _cleanup(mid)

    threading.Thread(target=process, daemon=True).start()


def _try_auto_start_client():
    scene = bpy.context.scene
    provider = getattr(scene, "aimcp_provider", "opencode-go")
    api_key = _get_api_key(provider)
    has_key = bool(api_key)
    print(f"[AUTO] _try_auto_start: provider={provider} key={'✅' if has_key else '❌'}")
    return has_key


def _respond(mid, text, is_status=False):
    def update():
        for s in bpy.data.scenes:
            for i, m in enumerate(s.aimcp_chat.msgs):
                if m.role == "status" and m.text.endswith("..."):
                    s.aimcp_chat.msgs.remove(i)
                    break
            if is_status:
                s.aimcp_chat.add("status", text, scene=s)
            else:
                s.aimcp_chat.add("assistant", text, scene=s)
                with bsock._chat_lock:
                    bsock._chat_queue[:] = [m for m in bsock._chat_queue if m["id"] != mid]
            s.aimcp_waiting = False
            s.aimcp_pending_msg_id = ""
            for screen in bpy.data.screens:
                for area in screen.areas:
                    area.tag_redraw()
            if not is_status:
                _append_to_log(text)
        return None
    bpy.app.timers.register(update, first_interval=0.0)


def _diagnose():
    lines = ["❌ No hay respuesta del agente. Diagnóstico:"]
    scene = bpy.context.scene

    provider = getattr(scene, "aimcp_provider", "?")
    model = getattr(scene, "aimcp_model", "?")
    api_key = _get_api_key(provider)

    if model and model != "?":
        lines.append(f"📌 Modelo: {model}")
    else:
        lines.append("📌 Ningún modelo seleccionado → Config → Refresh → selecciona uno")

    if api_key:
        lines.append(f"✅ API key presente para {provider}")
    else:
        lines.append(f"🔴 Falta API key para {provider}")
        lines.append("   • Ponla en variables de entorno")
        lines.append("   • O usa Local AI en Integrations (Ollama)")
        lines.append("   • O conecta Claude Desktop/Cursor como proxy")

    try:
        from .operators.embedded import _embedded_client
        if _embedded_client:
            lines.append("✅ Local AI activo")
        else:
            lines.append("ℹ️  Local AI no iniciado → click botón SYSTEM en el panel")
    except:
        pass

    try:
        import urllib.request
        req = urllib.request.Request("http://localhost:11434/api/version")
        with urllib.request.urlopen(req, timeout=2):
            lines.append("✅ Ollama detectado (pero no activo) → Integrations → Local AI")
    except:
        pass

    return "\n".join(lines)


def _cleanup(mid):
    _in_flight.pop(mid, None)
    _processed_ids.add(mid)
    _message_start.pop(mid, None)
