"""
blender-mcp — Autonomous Agent
"""
