"""
auto_process.py — Procesa la cola de chat dentro de Blender.
Timer que cada 0.5s revisa mensajes y los envía al LLM configurado.
Sin procesos externos. Sin mcp_server.py. Sin agent_host.py.
"""
import bpy
import json
import os
import re
import time
import threading
import traceback
import urllib.request
import logging
from datetime import datetime
from . import _axsock as bsock

logger = logging.getLogger("blender-mcp-auto")

_processed_ids = set()
_in_flight = {}
_message_start = {}
_timer_registered = False
_session_prefs = {}
_RETRY_LIMIT = 1


def start():
    global _timer_registered
    if _timer_registered:
        return
    bpy.app.timers.register(_tick, first_interval=0.5)
    _timer_registered = True


def _tick():
    try:
        with bsock._chat_lock:
            if not bsock._chat_queue:
                return _check_in_flight()
            messages = list(bsock._chat_queue)

        for msg in messages:
            mid = msg["id"]
            if mid in _processed_ids or mid in _in_flight:
                continue
            _in_flight[mid] = time.time()

            if mid not in _message_start:
                _message_start[mid] = time.time()

            elapsed = time.time() - _message_start[mid]
            text = msg["message"]
            print(f"[AUTO] mid={mid[:8]} text={text[:40]} elapsed={elapsed:.1f}s")

            if _try_auto_start_client():
                _process_with_client(mid, text)
                continue

            if elapsed > 30:
                del _in_flight[mid]
                txt = _diagnose()
                _respond(mid, txt)
                _cleanup(mid)

        return _check_in_flight()

    except Exception as e:
        logger.error(f"auto_process error: {e}")
        return 0.5


def _check_in_flight():
    now = time.time()
    for mid, started in list(_in_flight.items()):
        elapsed = now - started
        if elapsed > 30:
            _respond(mid, f"⏳ {elapsed:.0f}s", is_status=True, is_update=True)
            return 2.0
    return 0.5


def _detect_provider(model_id):
    PROVIDER_ORDER = ["google", "anthropic", "deepseek", "opencode-go", "openrouter"]
    _PROVIDER_API = {
        "deepseek": {"url": "https://api.deepseek.com/v1/models", "auth": True},
        "opencode-go": {"url": "https://opencode.ai/zen/go/v1/models", "auth": True},
        "openrouter": {"url": "https://openrouter.ai/api/v1/models", "auth": False},
        "google": {"url": "https://generativelanguage.googleapis.com/v1beta/models", "auth": True},
        "anthropic": {"url": "https://api.anthropic.com/v1/models", "auth": True},
    }
    for pid in PROVIDER_ORDER:
        if model_id.startswith(pid):
            return pid
    for pid in _PROVIDER_API:
        if pid in model_id:
            return pid
    return "opencode-go"


def _get_api_key(provider):
    env_map = {"opencode-go": "OPENAI_API_KEY", "deepseek": "DEEPSEEK_API_KEY",
               "openrouter": "OPENROUTER_API_KEY", "anthropic": "ANTHROPIC_API_KEY",
               "google": "GOOGLE_API_KEY"}
    key = os.environ.get(env_map.get(provider, ""), "")
    if key:
        return key
    try:
        from .platform_utils import get_opencode_auth_path
        p = get_opencode_auth_path()
        if p.exists():
            auth = json.loads(p.read_text())
            entry = auth.get(provider, {})
            if isinstance(entry, dict) and entry.get("key"):
                return entry["key"]
    except:
        pass
    try:
        from .config_cache import get_provider_config
        return get_provider_config(provider).get("api_key", "")
    except:
        pass
    return ""


_CHAT_URLS = {
    "opencode-go": "https://opencode.ai/zen/go/v1/chat/completions",
    "openai": "https://api.openai.com/v1/chat/completions",
    "deepseek": "https://api.deepseek.com/v1/chat/completions",
    "openrouter": "https://openrouter.ai/api/v1/chat/completions",
    "google": "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
    "anthropic": "https://api.anthropic.com/v1/messages",
    "ollama": "http://localhost:11434/v1/chat/completions",
}

_ANTHROPIC_HEADERS = {
    "anthropic-version": "2023-06-01",
    "content-type": "application/json",
}

SYSTEM_PROMPT = """Eres un asistente integrado en Blender 3D (Blender 4.2, Python API).

# REGLA DE ORO
ANTES de escribir CUALQUIER código de Blender, llama a `search_api_docs(consulta)` para buscar la API correcta en la documentación. No inventes nombres de funciones.

Ejemplo:
  Usuario: "crea un cilindro"
  Tú: llamas a search_api_docs("cylinder_add") → encuentras bpy.ops.mesh.primitive_cylinder_add
  Tú: escribes el código con los parámetros correctos

# HERRAMIENTAS DISPONIBLES
- `search_api_docs(query)` — Busca en la documentación de Blender. Siempre úsala primero.
- `get_python_api_docs(topic)` — Documentación detallada de un tema.
- `snap_to_anchor(obj_move, obj_target, anchor_move, anchor_target)` — Une objetos por anclas (27 pts).
- `snap_and_parent(obj_move, obj_target, anchor_move, anchor_target)` — Snap + parenting.
- `validate_geometry()` — Valida colisiones en toda la escena.
- `get_model_blueprint(obj)` — Blueprint completo de un objeto.

# REGLAS DE ENSAMBLAJE
- NO uses obj.location = (x, y, z). Usa snap_to_anchor o snap_and_parent.
- Después de ensamblar, llama a validate_geometry().
- NUNCA borres objetos existentes. Solo crea nuevos.

# ORGANIZACIÓN DE ESCENA
- REVISA la escena primero. Nombres únicos: "Mesa_001", "Mesa_002", etc.
- Nuevos objetos deben linkearse a una colección.
- Usa materiales con color siempre.

# FORMATO
- Código en ```python ... ```.
- Termina con print("OK")."""


# ─── Helpers para código generado ───

def _make_bezier_curve(name, points, bevel_depth=0.05, location=(0, 0, 0)):
    curve_data = bpy.data.curves.new(name=name + "Data", type='CURVE')
    curve_data.dimensions = '2D'
    curve_data.resolution_u = 12
    curve_data.bevel_depth = bevel_depth
    spline = curve_data.splines.new('BEZIER')
    spline.bezier_points.add(len(points) - 1)
    for i, co in enumerate(points):
        spline.bezier_points[i].co = co
    obj = bpy.data.objects.new(name, curve_data)
    obj.location = location
    bpy.context.collection.objects.link(obj)
    return obj


def _make_collection(name):
    col = bpy.data.collections.new(name)
    bpy.context.collection.children.link(col)
    return col


def _make_lathe(profile, name="LatheObj", location=(0, 0, 0), axis="Y", steps=64):
    if axis == "Y":
        pts = [(x, y, 0) for x, y in profile]
    else:
        pts = [(0, x, y) for x, y in profile]
    curve_data = bpy.data.curves.new(name=name + "Curve", type='CURVE')
    curve_data.dimensions = '2D'
    curve_data.resolution_u = steps
    spline = curve_data.splines.new('POLY')
    spline.points.add(len(pts) - 1)
    for i, p in enumerate(pts):
        spline.points[i].co = (p[0], p[1], p[2], 1)
    obj = bpy.data.objects.new(name, curve_data)
    obj.location = location
    bpy.context.collection.objects.link(obj)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.ops.object.convert(target='MESH')
    bpy.ops.object.modifier_add(type='SCREW')
    mod = obj.modifiers[-1]
    if axis == "Y":
        mod.axis = 'Y'
    else:
        mod.axis = 'X'
    mod.steps = steps // 2
    mod.render_steps = steps // 2
    mod.use_merge_vertices = True
    bpy.ops.object.modifier_apply(modifier=mod.name)
    return obj


def _ensure_unique_name(base):
    if base not in bpy.data.objects:
        return base
    i = 1
    while f"{base}_{i:03d}" in bpy.data.objects:
        i += 1
    return f"{base}_{i:03d}"


def _get_next_position():
    occupied = [obj.location.x for obj in bpy.context.scene.objects]
    if not occupied:
        return 0.0
    return max(occupied) + 3.0


def _render_preview():
    fp = "/tmp/blender_mcp_preview.png"
    bpy.context.scene.render.filepath = fp
    bpy.context.scene.render.resolution_x = 800
    bpy.context.scene.render.resolution_y = 600
    bpy.ops.render.render(write_still=True)
    import base64
    with open(fp, "rb") as f:
        return base64.b64encode(f.read()).decode()


_HELPER_NAMESPACE = {
    "bpy": bpy, "C": bpy.context, "D": bpy.data, "ops": bpy.ops,
    "make_curve": _make_bezier_curve,
    "make_collection": _make_collection,
    "make_lathe": _make_lathe,
    "render_preview": _render_preview,
    "unique_name": _ensure_unique_name,
    "next_pos": _get_next_position,
}

# Cargar el motor de ensamblaje al namespace para que el LLM pueda usarlo
try:
    from .assembly import AssemblyEngine
    _HELPER_NAMESPACE["AssemblyEngine"] = AssemblyEngine
    _HELPER_NAMESPACE["snap_to_anchor"] = AssemblyEngine.snap_to_anchor
    _HELPER_NAMESPACE["snap_and_parent"] = AssemblyEngine.snap_and_parent
    _HELPER_NAMESPACE["apply_symmetry"] = AssemblyEngine.apply_symmetry
    _HELPER_NAMESPACE["fix_normals"] = AssemblyEngine.fix_normals
except ImportError:
    pass

try:
    from .spatial import GeometryValidator
    _HELPER_NAMESPACE["validate_geometry"] = GeometryValidator.get_report
except ImportError:
    pass

try:
    from .scanner import GeometryScanner
    _HELPER_NAMESPACE["get_model_blueprint"] = GeometryScanner.get_blueprint
except ImportError:
    pass

# Buscador de documentación — la IA puede consultarlo desde código generado
try:
    import addon.rst_search as _rst
    _HELPER_NAMESPACE["search_api_docs"] = _rst.search_api_docs
    _HELPER_NAMESPACE["get_python_api_docs"] = _rst.get_python_api_docs
except ImportError:
    pass


# ─── Sesión: preferencias del usuario ───

def _parse_preferences(text, content):
    global _session_prefs
    text_lower = (text + " " + content).lower()
    color_keywords = {
        "rojo": (1, 0, 0, 1), "red": (1, 0, 0, 1),
        "azul": (0, 0, 1, 1), "blue": (0, 0, 1, 1),
        "verde": (0, 1, 0, 1), "green": (0, 1, 0, 1),
        "negro": (0, 0, 0, 1), "black": (0, 0, 0, 1),
        "blanco": (1, 1, 1, 1), "white": (1, 1, 1, 1),
        "amarillo": (1, 1, 0, 1), "yellow": (1, 1, 0, 1),
        "naranja": (1, 0.6, 0, 1), "orange": (1, 0.6, 0, 1),
        "morado": (0.5, 0, 1, 1), "purple": (0.5, 0, 1, 1),
        "rosa": (1, 0.4, 0.7, 1), "pink": (1, 0.4, 0.7, 1),
        "marrón": (0.5, 0.25, 0.1, 1), "brown": (0.5, 0.25, 0.1, 1),
        "gris": (0.5, 0.5, 0.5, 1), "gray": (0.5, 0.5, 0.5, 1),
    }
    for word, rgba in color_keywords.items():
        if word in text_lower and ("me gusta" in text_lower or "prefiero" in text_lower or "color" in text_lower):
            _session_prefs["color"] = rgba
            _session_prefs["color_name"] = word
            break


def _get_prefs_context():
    if not _session_prefs:
        return ""
    parts = []
    if "color_name" in _session_prefs:
        parts.append(f"color favorito: {_session_prefs['color_name']}")
    if "estilo" in _session_prefs:
        parts.append(f"estilo: {_session_prefs['estilo']}")
    return "Preferencias del usuario: " + ", ".join(parts) + "."


# ─── Ejecución de código en main thread ───

def _strip_bad_code(code):
    import re
    code = re.sub(r'^[ \t]*bpy\.context\.collection\.objects\.unlink\([^)]+\)\s*\n', '', code, flags=re.MULTILINE)
    code = re.sub(r'^[ \t]*bpy\.context\.scene\.collection\.objects\.unlink\([^)]+\)\s*\n', '', code, flags=re.MULTILINE)
    def _fix_scale(m):
        inner = m.group(1)
        inner = re.sub(r'\s*/\s*2\s*', '', inner)
        return '.scale = (' + inner + ')'
    code = re.sub(r'\.scale\s*=\s*\(([^)]*)\)', _fix_scale, code)
    return code

def _validate_code(code):
    try:
        from blender_mcp.utils.validator import validate
        return validate(code)
    except:
        return []

def _exec_code_main(code_blocks):
    results = []
    done = threading.Event()

    def execute():
        from .weak_sandbox import WeakSandboxForLLM
        for code in code_blocks:
            code = _strip_bad_code(code)
            errors = _validate_code(code)
            if errors:
                for e in errors:
                    results.append(str(e))
                continue
            try:
                import io
                from contextlib import redirect_stdout
                bpy.ops.ed.undo_push(message="AI ACTION")
                compiled = compile(code, "<blender_code>", "exec")
                buf = io.StringIO()
                with WeakSandboxForLLM():
                    with redirect_stdout(buf):
                        exec(compiled, _HELPER_NAMESPACE)
                bpy.context.view_layer.update()
                output = buf.getvalue().strip()
                if output:
                    results.insert(0, "__STDOUT__:" + output)
                print("[AUTO] Código ejecutado correctamente")
            except Exception as e:
                err = f"Error: {e}"
                print(f"[AUTO] {err}")
                results.append(err)
        if not results:
            try:
                b64 = _render_preview()
                results.insert(0, "__PREVIEW__:" + b64)
            except:
                pass
        done.set()
        return None

    bpy.app.timers.register(execute, first_interval=0.0)
    done.wait(timeout=10)
    return results


def _append_to_log(text, tag="AI"):
    try:
        log_path = os.path.expanduser("~/.config/blender-mcp/chat_log.txt")
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        with open(log_path, "a") as f:
            f.write(f"[{datetime.now().strftime('%H:%M')}] {tag}: {text}\n\n")
    except:
        pass


def _get_scene_context():
    lines = []
    names = []
    for obj in bpy.context.scene.objects:
        loc = obj.location
        dims = obj.dimensions
        lines.append(f"- {obj.name} | {obj.type} | ({loc.x:.2f}, {loc.y:.2f}, {loc.z:.2f}) | ({dims.x:.2f}, {dims.y:.2f}, {dims.z:.2f})")
        names.append(obj.name)
    ctx = "Estado actual de la escena:\n" + "\n".join(lines) if lines else "Escena vacía."
    ctx += f"\nNombres ocupados: {', '.join(names) if names else '(ninguno)'}"
    ctx += f"\nSiguiente posición X libre: {_get_next_position():.1f}"
    return ctx


def _get_timeout(text):
    if len(text) > 50 or any(w in text.lower() for w in ("detalle", "detallado", "completo", "complej", "carro", "vehículo", "edificio", "mueble", "organico", "escena")):
        return 90
    return 60

def _call_llm(url, headers, model, messages, text=""):
    body = json.dumps({
        "model": model,
        "messages": messages,
        "max_tokens": 8192,
        "temperature": 0.4,
    }).encode()
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=_get_timeout(text)) as resp:
        return json.loads(resp.read())


def _call_anthropic(url, headers, api_key, model, messages, text=""):
    system = ""
    msgs = []
    for m in messages:
        if m["role"] == "system":
            system += m["content"] + "\n"
        elif m["role"] in ("user", "assistant"):
            msgs.append({"role": m["role"], "content": m["content"]})
    body = json.dumps({
        "model": model,
        "max_tokens": 8192,
        "system": system.strip(),
        "messages": msgs,
        "temperature": 0.4,
    }).encode()
    hdrs = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    req = urllib.request.Request(url, data=body, headers=hdrs, method="POST")
    with urllib.request.urlopen(req, timeout=_get_timeout(text)) as resp:
        return json.loads(resp.read())


_VISION_PROVIDERS = {"opencode-go", "openai", "openrouter", "google", "anthropic"}

def _capture_screenshot_b64():
    try:
        from .handlers.analysis import AnalysisHandler
        return AnalysisHandler.cmd_get_screenshot_as_base64()
    except:
        return None


# ─── Comandos directos (sin LLM) ───
_AKB_COMMANDS = {
    "!akb_help": "Muestra esta ayuda.\n  !akb_list - Lista categorías y blueprints\n  !feed_category <cat>, <kw1>, <kw2>... - Busca y descarga modelos\n  !feed_all - Puebla todas las categorías\n  !akb_specs <query> - Busca specs en AKB",
    "!akb_list": None,
    "!feed_category": None,
    "!feed_all": None,
    "!akb_specs": None,
    "!akb_clean": "Limpia todos los objetos de prueba de la escena.",
}


def _handle_command(mid, text):
    parts = text.strip().split()
    cmd = parts[0].lower()
    args = parts[1:]

    if cmd == "!akb_help":
        _respond(mid, _AKB_COMMANDS["!akb_help"])
        _cleanup(mid)
        return True

    if cmd == "!akb_list":
        try:
            from .akb import list_categories
            cats = list_categories()
            msg = "📋 **AKB Blueprints:**\n"
            for c in cats:
                msg += f"\n📁 {c['category']} ({c['count']} objetos)"
            _respond(mid, msg)
        except Exception as e:
            _respond(mid, f"❌ Error: {e}")
        _cleanup(mid)
        return True

    if cmd == "!akb_specs" and args:
        try:
            from .akb import get_specs
            results = get_specs(" ".join(args))
            if results:
                msg = f"🔍 **{len(results)} resultados para '{' '.join(args)}':**\n"
                for bp in results[:5]:
                    meta = bp.get("metadata", {})
                    geo = bp.get("geometry", {})
                    dims = geo.get("dimensions", "?")
                    src = meta.get("source", "?")
                    name = meta.get("name", "?")
                    msg += f"\n- {name}: {dims} [{src}]"
            else:
                msg = f"❌ No se encontraron blueprints para '{' '.join(args)}'"
            _respond(mid, msg)
        except Exception as e:
            _respond(mid, f"❌ Error: {e}")
        _cleanup(mid)
        return True

    if cmd == "!feed_category":
        _VALID_CATS = {"av":["av","audio","audivisual","audiovisual","video","sonido","a/v"],
                       "furniture":["furniture","muebles","mueble","furni"],
                       "vehicles":["vehicles","vehiculos","autos","carros"],
                       "structural":["structural","estructura","construccion"]}
        def _resolve_cat(name):
            name = name.lower().strip()
            for cat, syns in _VALID_CATS.items():
                if name in syns:
                    return cat
            return name
        
        if not args:
            cats = ", ".join(_VALID_CATS.keys())
            _respond(mid, f"⚠️ Uso: !feed_category <categoria>, <keyword1>, <keyword2>...\nCategorías válidas: {cats}\nEj: !feed_category av, truss, speaker")
            _cleanup(mid)
            return True
        
        full = " ".join(args)
        parts = [p.strip() for p in full.split(",")]
        raw_cat = parts[0]
        category = _resolve_cat(raw_cat)
        if category != raw_cat:
            _respond(mid, f"🔀 '{raw_cat}' → categoría '{category}'", is_status=True)
        keywords = parts[1:] if len(parts) > 1 else [category]
        
        # Validate category exists
        from .akb import _ensure_dirs
        from pathlib import Path
        akb_base = Path(__file__).parent / "data" / "akb"
        if not (akb_base / category).exists():
            cats = ", ".join(_VALID_CATS.keys())
            _respond(mid, f"❌ Categoría '{category}' no existe. Válidas: {cats}\nEj: !feed_category av, truss, speaker")
            _cleanup(mid)
            return True
        
        _respond(mid, f"⏳ Buscando {keywords} en {category}...", is_status=True)
        
        def feed():
            try:
                from .akb_fetcher import feed_from_polyhaven
                result = feed_from_polyhaven(category, keywords)
                total = result.get("feeded", 0)
                if total == 0:
                    msg = f"⚠️ No se encontraron modelos para {keywords} en Poly Haven.\nPrueba otras palabras clave o verifica la categoría."
                else:
                    msg = f"✅ **{total} nuevo(s) blueprint(s) en {category}:**"
                    for item in result.get("items", []):
                        dims = item.get("dimensions", "?")
                        msg += f"\n- {item['name']}: {dims}"
                _respond(mid, msg)
            except Exception as e:
                _respond(mid, f"❌ Error: {e}")
            _cleanup(mid)
        threading.Thread(target=feed, daemon=True).start()
        return True

    if cmd == "!feed_all":
        _respond(mid, "⏳ Alimentando todas las categorías... (puede tomar varios minutos)", is_status=True)
        
        def feed_all():
            try:
                from .akb_fetcher import feed_from_polyhaven
                cats = {"av": ["truss", "speaker", "microphone", "camera", "monitor"],
                         "furniture": ["table", "chair", "desk", "shelf", "cabinet"],
                         "vehicles": ["car", "truck", "bicycle"],
                         "structural": ["door", "window", "beam"]}
                total = 0
                msg = "✅ **Alimentación global completada:**\n"
                for cat, kws in cats.items():
                    r = feed_from_polyhaven(cat, kws)
                    n = r.get("feeded", 0)
                    total += n
                    msg += f"\n- {cat}: {n} blueprints"
                    for item in r.get("items", []):
                        dims = item.get("dimensions", "?")
                        msg += f"\n  • {item['name']}: {dims}"
                msg += f"\n\n**Total: {total} nuevos blueprints**"
                _respond(mid, msg)
            except Exception as e:
                _respond(mid, f"❌ Error: {e}")
            _cleanup(mid)
        threading.Thread(target=feed_all, daemon=True).start()
        return True

    if cmd == "!akb_clean":
        _respond(mid, "🧹 Limpiando objetos de prueba...", is_status=True)
        try:
            import bpy
            count = 0
            for obj in list(bpy.data.objects):
                if obj.name not in ("Cube", "Camera", "Light", "tx"):
                    bpy.data.objects.remove(obj, do_unlink=True)
                    count += 1
            _respond(mid, f"✅ Escena limpia. {count} objetos eliminados.")
        except Exception as e:
            _respond(mid, f"❌ Error: {e}")
        _cleanup(mid)
        return True

    return False


def _process_with_client(mid, text):
    # Check for direct commands first
    if text.strip().startswith("!"):
        if _handle_command(mid, text):
            return

    scene = bpy.context.scene
    model = getattr(scene, "aimcp_model", "")
    provider = _detect_provider(model) if model else "opencode-go"
    print(f"[AUTO] provider={provider} model={model}")
    api_key = _get_api_key(provider)
    print(f"[AUTO] api_key={'✅' if api_key else '❌'}")

    if not api_key:
        _respond(mid, "❌ No hay API key para " + provider)
        _cleanup(mid)
        return

    url = _CHAT_URLS.get(provider)
    if not url:
        _respond(mid, f"❌ Provider {provider} no soportado")
        _cleanup(mid)
        return

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
        "User-Agent": "blender-mcp/0.8",
    }

    timeout = _get_timeout(text)
    if timeout > 60:
        _respond(mid, "⏳ Generando código detallado...", is_status=True)
    else:
        _respond(mid, "⏳ Pensando...", is_status=True)

    def process():
        nonlocal text
        is_timeout_retry = False

        for retry in range(_RETRY_LIMIT + 1):
            if bsock._stop_agent:
                _respond(mid, "⛔ Detenido por el usuario")
                _cleanup(mid)
                return
            if retry > 0:
                if is_timeout_retry:
                    print(f"[AUTO] Reintento por timeout, prompt simplificado...")
                    text = f"{text_original}. Genera código CORTO, solo las partes más importantes, máximo 30 líneas."
                else:
                    print(f"[AUTO] Reintento {retry}/{_RETRY_LIMIT} con feedback de error...")
                    ctx = _get_scene_context()
                    text = text_original

            messages = [{"role": "system", "content": SYSTEM_PROMPT}]

            ctx = _get_scene_context()
            messages.append({"role": "system", "content": ctx})
            if retry > 0 and not is_timeout_retry:
                messages.append({"role": "system", "content": f"El intento anterior falló. Error: {errors[0]}. Escena actualizada arriba. Corrige el código."})

            prefs = _get_prefs_context()
            if prefs:
                messages.append({"role": "system", "content": prefs})

            user_msg = text

            if provider in _VISION_PROVIDERS:
                shot = _capture_screenshot_b64()
                if shot and "base64" in shot:
                    user_msg = [
                        {"type": "text", "text": text},
                        {"type": "image_url", "image_url": {"url": f"data:{shot['mime']};base64,{shot['base64']}"}},
                    ]

            messages.append({"role": "user", "content": user_msg})

            is_anthropic = provider == "anthropic"
            try:
                if is_anthropic:
                    result = _call_anthropic(url, headers, api_key, model, messages, text)
                    content = ""
                    for block in result.get("content", []):
                        if block.get("type") == "text":
                            content += block.get("text", "")
                else:
                    result = _call_llm(url, headers, model, messages, text)
                    content = result.get("choices", [{}])[0].get("message", {}).get("content", "")
            except urllib.error.HTTPError as e:
                err = e.read().decode()[:200]
                print(f"[AUTO] HTTP Error {e.code}: {err}")
                if retry < _RETRY_LIMIT:
                    text_original = text
                    text = f"Error HTTP {e.code}. Reintenta con código más simple."
                    continue
                _respond(mid, f"❌ HTTP {e.code}")
                _cleanup(mid)
                return
            except Exception as e:
                is_timeout = isinstance(e, TimeoutError) or "timed out" in str(e).lower()
                if is_timeout and retry < _RETRY_LIMIT:
                    text_original = text
                    is_timeout_retry = True
                    _respond(mid, "⏳ Simplificando y reintentando...", is_status=True)
                    continue
                print(f"[AUTO] Error: {traceback.format_exc()}")
                _respond(mid, f"❌ Error: {str(e)[:60]}")
                _cleanup(mid)
                return

            if not content:
                _respond(mid, "⚠️ El modelo no generó respuesta")
                _cleanup(mid)
                return

            print(f"[AUTO] Respuesta recibida ({len(content)} chars)")

            _parse_preferences(text, content)

            code_blocks = re.findall(r'```python\n(.*?)```', content, re.DOTALL)
            errors = []
            if code_blocks:
                print(f"[AUTO] Ejecutando {len(code_blocks)} bloque(s) de código en main thread...")
                errors = _exec_code_main(code_blocks)

            real_errors = [e for e in errors if not e.startswith("__")]
            if not real_errors:
                break

            if retry == 0:
                text_original = text

        preview_b64 = None
        for e in errors:
            if e.startswith("__PREVIEW__:"):
                preview_b64 = e[12:]
                errors.remove(e)
                break
        if errors:
            content += "\n\n---\n⚠️ Error al ejecutar:\n" + "\n".join(errors)
        if preview_b64:
            content += "\n\n![preview](data:image/png;base64," + preview_b64 + ")"

        _respond(mid, content)
        _cleanup(mid)

    threading.Thread(target=process, daemon=True).start()


def _try_auto_start_client():
    scene = bpy.context.scene
    provider = getattr(scene, "aimcp_provider", "opencode-go")
    api_key = _get_api_key(provider)
    has_key = bool(api_key)
    print(f"[AUTO] _try_auto_start: provider={provider} key={'✅' if has_key else '❌'}")
    return has_key


def _respond(mid, text, is_status=False, is_update=False):
    def update():
        for s in bpy.data.scenes:
            if is_status:
                for i, m in enumerate(s.aimcp_chat.msgs):
                    if m.role == "status":
                        s.aimcp_chat.msgs.remove(i)
                        break
                s.aimcp_chat.add("status", text, scene=s)
            else:
                s.aimcp_chat.add("assistant", text, scene=s)
                with bsock._chat_lock:
                    bsock._chat_queue[:] = [m for m in bsock._chat_queue if m["id"] != mid]
                s.aimcp_waiting = False
            s.aimcp_pending_msg_id = ""
            for screen in bpy.data.screens:
                for area in screen.areas:
                    area.tag_redraw()
            if not is_status:
                _append_to_log(text)
        return None
    bpy.app.timers.register(update, first_interval=0.0)


def _diagnose():
    lines = ["❌ No hay respuesta del agente. Diagnóstico:"]
    scene = bpy.context.scene

    provider = getattr(scene, "aimcp_provider", "?")
    model = getattr(scene, "aimcp_model", "?")
    api_key = _get_api_key(provider)

    if model and model != "?":
        lines.append(f"📌 Modelo: {model}")
    else:
        lines.append("📌 Ningún modelo seleccionado → Config → Refresh → selecciona uno")

    if api_key:
        lines.append(f"✅ API key presente para {provider}")
    else:
        lines.append(f"🔴 Falta API key para {provider}")
        lines.append("   • Ponla en variables de entorno")
        lines.append("   • O usa Local AI en Integrations (Ollama)")
        lines.append("   • O conecta Claude Desktop/Cursor como proxy")

    try:
        from .operators.embedded import _embedded_client
        if _embedded_client:
            lines.append("✅ Local AI activo")
        else:
            lines.append("ℹ️  Local AI no iniciado → click botón SYSTEM en el panel")
    except:
        pass

    try:
        import urllib.request
        req = urllib.request.Request("http://localhost:11434/api/version")
        with urllib.request.urlopen(req, timeout=2):
            lines.append("✅ Ollama detectado (pero no activo) → Integrations → Local AI")
    except:
        pass

    return "\n".join(lines)


def _cleanup(mid):
    _in_flight.pop(mid, None)
    _processed_ids.add(mid)
    _message_start.pop(mid, None)
