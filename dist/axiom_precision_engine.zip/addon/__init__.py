# blender-mcp — AI Assistant for Blender v0.2.0
# Panels: Config (Properties) + Chat (3D View Sidebar)
# Includes internal HTTP server (port 9878) for direct bpy commands from MCP/HTTP bridge
bl_info = {
    "name": "AXIOM Precision Engine",
    "author": "CarlosH & Antigravity",
    "version": (1, 0, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Axiom tab",
    "description": "Deterministic Geometry & Vision-Powered AI Assembly",
    "doc_url": "https://github.com/carlosh7/blender-mcp",
    "category": "3D View",
}
import bpy, os, json, time, mathutils, sys, threading, urllib.request
from bpy.props import StringProperty, IntProperty, CollectionProperty, BoolProperty, PointerProperty
from bpy.types import Panel, Operator, PropertyGroup, UIList

# Añadimos la ruta local para encontrar blender_socket y spatial
sys.path.insert(0, os.path.dirname(__file__))
import blender_socket as bsock
from . import spatial # Inteligencia Espacial

# ─── Provider API config for fetching model lists ───
_PROVIDER_API = {
    "deepseek": {"url": "https://api.deepseek.com/v1/models", "auth": True},
    "opencode-go": {"url": "https://opencode.ai/zen/go/v1/models", "auth": True},
    "openrouter": {"url": "https://openrouter.ai/api/v1/models", "auth": False},
    "google": {"url": "https://generativelanguage.googleapis.com/v1beta/models", "auth": True},
    "anthropic": {"url": "https://api.anthropic.com/v1/models", "auth": True},
}
def _get_api_key(provider_id):
    """Get API key for a provider from auth.json or env vars."""
    auth_path = os.path.expanduser("~/.local/share/opencode/auth.json")
    if os.path.exists(auth_path):
        try:
            auth = json.loads(open(auth_path).read())
            entry = auth.get(provider_id)
            if isinstance(entry, dict) and entry.get("key"):
                return entry["key"]
        except: pass
    # Check env vars
    env_map = {
        "deepseek": "DEEPSEEK_API_KEY", 
        "openrouter": "OPENROUTER_API_KEY",
        "google": "GOOGLE_API_KEY",
        "anthropic": "ANTHROPIC_API_KEY"
    }
    env_var = env_map.get(provider_id)
    if env_var:
        return os.environ.get(env_var)
    return None

SPINNER_FRAMES = ["\u280b", "\u2819", "\u2839", "\u2838", "\u283c", "\u2834", "\u2826", "\u2827", "\u2807", "\u280f"]

# ─── Persistencia ───
def get_history_path():
    """Devuelve la ruta del chat solo si el archivo .blend está guardado."""
    blend_path = bpy.data.filepath
    if not blend_path: return None
    return blend_path + ".chat"

def load_history(chat):
    path = get_history_path()
    if not path:
        chat.msgs.clear()
        chat.count = 0
        return
    
    chat.msgs.clear()
    if os.path.exists(path):
        try:
            with open(path, 'r') as f:
                data = json.loads(f.read())
                for m in data:
                    item = chat.msgs.add()
                    item.role = m['role']; item.text = m['text']
            chat.count = len(chat.msgs)
        except: pass

def wrap_text(text, max_chars=45):
    lines = []
    for p in text.split("\n"):
        if not p: lines.append(""); continue
        words = p.split()
        curr = []
        curr_len = 0
        for w in words:
            if curr_len + len(w) > max_chars:
                lines.append(" ".join(curr)); curr = [w]; curr_len = len(w)
            else:
                curr.append(w); curr_len += len(w) + 1
        if curr: lines.append(" ".join(curr))
    return lines

def save_history(chat):
    path = get_history_path()
    if not path: return
    
    # Reagrupamos las líneas en mensajes completos para el archivo JSON
    full_msgs = []
    curr_text = []
    curr_role = ""
    
    for m in chat.msgs:
        if m.role == 'status': continue
        if m.is_new:
            if curr_role:
                full_msgs.append({"role": curr_role, "text": " ".join(curr_text)})
            curr_role = m.role
            curr_text = [m.text]
        else:
            curr_text.append(m.text)
            
    if curr_role:
        full_msgs.append({"role": curr_role, "text": " ".join(curr_text)})
        
    try:
        with open(path, 'w') as f:
            f.write(json.dumps(full_msgs, indent=2))
    except: pass

# ─── Chat ───
class ChatMsg(PropertyGroup):
    role: StringProperty()
    text: StringProperty()
    is_new: BoolProperty(default=False)

class ChatData(PropertyGroup):
    msgs: CollectionProperty(type=ChatMsg)
    count: IntProperty(default=0)
    def add(self, r, t, is_update=False, scene=None):
        # Detectamos si el usuario ya estaba al final para decidir si le seguimos (Smart Scroll)
        was_at_bottom = False
        if scene:
            was_at_bottom = (scene.aimcp_chat_index >= len(self.msgs) - 1)

        if is_update:
            while len(self.msgs) > 0 and self.msgs[-1].role == r and not self.msgs[-1].is_new:
                self.msgs.remove(len(self.msgs)-1)
            if len(self.msgs) > 0 and self.msgs[-1].role == r and self.msgs[-1].is_new:
                self.msgs.remove(len(self.msgs)-1)

        lines = wrap_text(t)
        for i, l_txt in enumerate(lines):
            m = self.msgs.add()
            m.role = r; m.text = l_txt
            m.is_new = (i == 0)
            
        self.count = len(self.msgs)
        # Scroll inteligente: bajamos si ya estábamos al final o si es un mensaje nuevo tuyo
        if scene and (was_at_bottom or r == 'user' or (not is_update and r == 'assistant')):
            scene.aimcp_chat_index = self.count - 1
        save_history(self)

    def clear_all(self):
        # Limpiamos TODAS las escenas para evitar resurrecciones del archivo
        for s in bpy.data.scenes:
            while s.aimcp_chat.msgs:
                s.aimcp_chat.msgs.remove(0)
            s.aimcp_chat.count = 0
        txt_block = bpy.data.texts.get("aimcp_chat_history")
        if txt_block:
            bpy.data.texts.remove(txt_block)

# --- Chat Drawing ---

class MCP_UL_Chat(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if not item: return
        row = layout.row(align=True)
        if item.is_new:
            tag = "Usted" if item.role == "user" else "IA" if item.role == "assistant" else "Pensando" if item.role == "status" else "Sys"
            row.label(text=f"[{tag}] {item.text}")
        else:
            row.label(text=f"      {item.text}")

# ─── Model ───
class ModelItem(PropertyGroup):
    model_id: StringProperty(); model_name: StringProperty(); provider: StringProperty()

class ModelsData(PropertyGroup):
    items: CollectionProperty(type=ModelItem); count: IntProperty(default=0)
    def add(self, mid, name, prov):
        m = self.items.add(); m.model_id = mid; m.model_name = name; m.provider = prov; self.count = len(self.items)
    def clear_all(self):
        while self.items: self.items.remove(0); self.count = 0

PROVIDER_ORDER = ["google", "anthropic", "deepseek", "opencode-go", "openrouter"]
PROVIDER_LABELS = {
    "google": "Google Gemini", 
    "anthropic": "Anthropic Claude",
    "deepseek": "DeepSeek", 
    "opencode-go": "OpenCode Go", 
    "openrouter": "OpenRouter"
}

# ─── Config Panel ───
class PN_PT_Config(Panel):
    bl_label = "Axiom Engine Config"; bl_idname = "PN_PT_Config"
    bl_space_type = 'PROPERTIES'; bl_region_type = 'WINDOW'; bl_context = 'scene'

    def draw(self, ctx):
        L = self.layout; c = ctx.scene
        box = L.box()
        box.label(text="Status", icon='LINKED')
        row = box.row(align=True)
        is_connected = bsock._socket_server is not None and bsock._socket_server.running
        if is_connected:
            row.label(text="Socket: Online", icon='CHECKBOX_HLT')
        else:
            row.label(text="Socket: Offline", icon='CHECKBOX_DEHLT')

        L.separator()
        box = L.box()
        box.label(text="AI Model", icon='SETTINGS')
        current = c.aimcp_model or "(reading from opencode.json...)"
        box.label(text=f"Current: {current}")
        row = box.row(align=True)
        row.operator("aimcp.refresh", text="Refresh", icon='FILE_REFRESH')

        md = c.aimcp_models
        if md and md.count > 0:
            for prov_id in PROVIDER_ORDER:
                prov_models = [m for m in md.items if m.provider == prov_id]
                if not prov_models: continue
                
                # SECCIÓN PLEGABLE POR PROVEEDOR
                prop_name = f"aimcp_show_{prov_id.replace('-','_')}"
                is_expanded = getattr(c, prop_name, False)
                
                box_prov = box.box()
                row = box_prov.row(align=True)
                # Botón de plegado más profesional
                row.prop(c, prop_name, 
                         text=PROVIDER_LABELS.get(prov_id, prov_id), 
                         icon='TRIA_DOWN' if is_expanded else 'TRIA_RIGHT', 
                         icon_only=False, emboss=False)
                
                if is_expanded:
                    col = box_prov.column(align=True)
                    for m in prov_models:
                        row = col.row(align=True)
                        if m.model_id == current:
                            row.label(text="", icon='RADIOBUT_ON')
                            row.label(text=f"{m.model_name}")
                        else:
                            op = row.operator("aimcp.select", text=m.model_id, icon='RADIOBUT_OFF'); op.model_id = m.model_id
        else:
            row = box.row(align=True)
            row.operator("aimcp.refresh", text="Load models", icon='FILE_REFRESH')

        L.separator()
        status = c.aimcp_status
        if status: L.label(text=status, icon='INFO')

# ─── Chat Panel ───
class PN_PT_Chat(Panel):
    bl_label = "AXIOM Chat Panel"; bl_idname = "PN_PT_Chat"
    bl_space_type = 'VIEW_3D'; bl_region_type = 'UI'; bl_category = 'Axiom'

    def draw(self, ctx):
        L = self.layout; c = ctx.scene
        state = c.aimcp_ai_state
        m = c.aimcp_model or "?"
        if len(m) > 18: m = m[:17] + ".."

        # FILA 1: ESTADO + CONEXIÓN + STOP
        row = L.row(align=True)
        if not c.aimcp_connected:
            row.operator("aimcp.check", text="Connect", icon='ADD')
            row.label(text=m)
        else:
            row.operator("aimcp.disconnect", text="", icon='X')
            row.label(text="Online", icon='CHECKBOX_HLT')
            if c.aimcp_waiting:
                row.operator("aimcp.stop_agent", text="STOP", icon='CANCEL')
            row.label(text=m)

        # FILA 2: UTILIDADES
        row = L.row(align=True)
        row.operator("aimcp.capture", text="Axiom Vision", icon='CAMERA_DATA')
        row.operator("aimcp.export", text="Axiom Export", icon='EXPORT')

        # CHAT DINÁMICO (Máximo 11 filas)
        L.separator()
        col = L.column(align=True)
        # La altura crece con las líneas hasta un tope de 11
        num_lines = len(c.aimcp_chat.msgs)
        chat_rows = min(max(num_lines, 2), 11)
        col.template_list("MCP_UL_Chat", "", c.aimcp_chat, "msgs", c, "aimcp_chat_index", rows=chat_rows)
        
        # INPUT Y BOTONES (Fila única y proporcionada)
        L.separator()
        L.prop(c, "aimcp_input", text="")
        row = L.row(align=True); row.scale_y = 1.2
        row.operator("aimcp.send", text="Enviar", icon='PLAY')
        row.operator("aimcp.clear_chat", text="Limpiar", icon='X')

# ─── Operators ───
class OP_Check(Operator):
    bl_idname = "aimcp.check"; bl_label = "Check Connection"
    def execute(self, ctx):
        ctx.scene.aimcp_status = "Checking..."
        if ctx.area: ctx.area.tag_redraw()
        connected = bsock._socket_server is not None and bsock._socket_server.running
        ctx.scene.aimcp_connected = connected
        ctx.scene.aimcp_status = "Connected" if connected else "Socket not running"
        if ctx.area: ctx.area.tag_redraw()
        return {'FINISHED'}

class OP_Refresh(Operator):
    bl_idname = "aimcp.refresh"; bl_label = "Refresh"
    def execute(self, ctx):
        ctx.scene.aimcp_status = "Loading..."
        if ctx.area: ctx.area.tag_redraw()

        # Read current model from opencode config
        model = ""
        for p in [os.path.expanduser("~/.config/opencode/opencode.json"),
                  os.path.expanduser("~/Check/opencode.json")]:
            if os.path.exists(p):
                try:
                    d = json.loads(open(p).read())
                    if d.get("model"): model = d["model"]; break
                except: pass

        # Read connected providers from auth.json
        auth_path = os.path.expanduser("~/.local/share/opencode/auth.json")
        providers = []
        if os.path.exists(auth_path):
            try:
                auth = json.loads(open(auth_path).read())
                for prov_id in auth:
                    entry = auth[prov_id]
                    if isinstance(entry, dict) and entry.get("key"):
                        providers.append(prov_id)
            except: pass

        # Fetch models from each provider API (in thread)
        def fetch_all():
            all_models = []
            for prov_id in providers:
                cfg = _PROVIDER_API.get(prov_id)
                if not cfg: continue
                try:
                    headers = {"User-Agent": "blender-mcp/0.12", "Accept": "application/json"}
                    if cfg["auth"]:
                        key = _get_api_key(prov_id)
                        if not key: continue
                        headers["Authorization"] = f"Bearer {key}"
                    req = urllib.request.Request(cfg["url"], headers=headers)
                    with urllib.request.urlopen(req, timeout=10) as resp:
                        raw = json.loads(resp.read())
                    raw_list = raw.get("data", raw)
                    if isinstance(raw_list, list):
                        for m in raw_list:
                            mid = m.get("id", "")
                            if not mid: continue
                            all_models.append({
                                "id": mid,
                                "name": m.get("name") or mid.split("/")[-1].replace("-", " ").title(),
                                "provider": prov_id,
                            })
                except: pass

            def update():
                md = ctx.scene.aimcp_models; md.clear_all()
                if model: ctx.scene.aimcp_model = model
                for m in all_models:
                    md.add(m["id"], m["name"], m["provider"])
                prov_count = len(set(m["provider"] for m in all_models))
                prov_names = ", ".join(PROVIDER_LABELS.get(p, p) for p in sorted(set(m["provider"] for m in all_models)))
                ctx.scene.aimcp_status = f"{len(all_models)} models from {prov_count} providers"
                if ctx.area: ctx.area.tag_redraw()
            bpy.app.timers.register(update, first_interval=0.01)

        threading.Thread(target=fetch_all, daemon=True).start()
        return {'FINISHED'}

class OP_SelectModel(Operator):
    bl_idname = "aimcp.select"; bl_label = "Select"
    model_id: StringProperty()
    def execute(self, ctx):
        ctx.scene.aimcp_model = self.model_id; ctx.scene.aimcp_status = f"Selected: {self.model_id}"
        if ctx.area: ctx.area.tag_redraw(); return {'FINISHED'}

class OP_ApplyModel(Operator):
    bl_idname = "aimcp.apply_model"; bl_label = "Apply"
    model_id: StringProperty()
    def execute(self, ctx):
        mid = self.model_id
        ctx.scene.aimcp_model = mid
        ctx.scene.aimcp_status = "Saved"
        # Write to opencode config
        config_paths = [
            os.path.expanduser("~/.config/opencode/opencode.json"),
            os.path.expanduser("~/Check/opencode.json"),
        ]
        for p in config_paths:
            if os.path.exists(p):
                try:
                    d = json.loads(open(p).read())
                    d["model"] = mid
                    open(p, "w").write(json.dumps(d, indent=2) + "\n")
                    ctx.scene.aimcp_status = f"Saved to {os.path.basename(p)}"
                    break
                except: pass
        if ctx.area: ctx.area.tag_redraw()
        return {'FINISHED'}

class OP_ClearSearch(Operator):
    bl_idname = "aimcp.clear_search"; bl_label = "Clear"
    search_prop: StringProperty()
    def execute(self, ctx):
        if self.search_prop and hasattr(ctx.scene, self.search_prop): setattr(ctx.scene, self.search_prop, "")
        if ctx.area: ctx.area.tag_redraw(); return {'FINISHED'}

class OP_Disconnect(Operator):
    bl_idname = "aimcp.disconnect"; bl_label = "Disconnect"
    def execute(self, ctx):
        bsock.stop_socket_server()
        ctx.scene.aimcp_connected = False; ctx.scene.aimcp_status = ""
        if ctx.area: ctx.area.tag_redraw(); return {'FINISHED'}

class OP_Send(Operator):
    bl_idname = "aimcp.send"; bl_label = "Send"
    def execute(self, ctx):
        # RESETEAR STOP AL ENVIAR
        bsock._stop_agent = False
        
        if not ctx.scene.aimcp_model:
            ctx.scene.aimcp_chat.add("system", "Error: Por favor, selecciona un modelo en la pestaña de Configuración primero.", scene=ctx.scene)
            return {'CANCELLED'}

        txt = ctx.scene.aimcp_input.strip()
        if not txt: return {'CANCELLED'}
        ctx.scene.aimcp_chat.add("user", txt, scene=ctx.scene)
        ctx.scene.aimcp_input = ""
        ctx.scene.aimcp_waiting = True
        ctx.scene.aimcp_pending_msg_id = ""
        if ctx.area: ctx.area.tag_redraw()
        # Queue message in-process — socket server reads it, MCP responds
        msg_id = str(time.time())
        with bsock._chat_lock:
            bsock._chat_queue.append({"id": msg_id, "message": txt, "timestamp": time.time()})
        ctx.scene.aimcp_pending_msg_id = msg_id
        # --- POLLING PARA RESPUESTAS ---
        def check():
            scene = getattr(bpy.context, "scene", None)
            if not scene: return 1.0
            mid = scene.aimcp_pending_msg_id
            if not mid: return None
            
            with bsock._chat_lock:
                # 1. Buscamos pensamientos (status)
                status = bsock._chat_responses.get(mid + "_status", None)
                if status:
                    scene.aimcp_chat.add("status", status, is_update=True, scene=scene)
                
                # 2. Buscamos la respuesta final
                resp = bsock._chat_responses.pop(mid, None)
                
            if resp is None: return 0.5 
            
            # Limpiamos el pensamiento temporal antes de la respuesta final
            if len(scene.aimcp_chat.msgs) > 0 and scene.aimcp_chat.msgs[-1].role == 'status' and scene.aimcp_chat.msgs[-1].text.endswith("..."):
                scene.aimcp_chat.msgs.remove(len(scene.aimcp_chat.msgs)-1)
            
            scene.aimcp_chat.add("assistant", resp, scene=scene)
            scene.aimcp_status = ""
            scene.aimcp_waiting = False
            scene.aimcp_pending_msg_id = ""
            bsock._chat_responses.pop(mid + "_status", None)
            return None
        bpy.app.timers.register(check, first_interval=0.5)
        return {'FINISHED'}

class OP_Capture(Operator):
    bl_idname = "aimcp.capture"; bl_label = "Capture"
    def execute(self, ctx):
        n = len(bpy.data.objects); m = sum(1 for o in bpy.data.objects if o.type == 'MESH')
        ctx.scene.aimcp_chat.add("system", f"Scene: {n} objects, {m} meshes")
        if ctx.area: ctx.area.tag_redraw(); return {'FINISHED'}

class OP_Export(Operator):
    bl_idname = "aimcp.export"; bl_label = "Export"
    def execute(self, ctx):
        out = os.path.expanduser("~/blender-mcp/models/scene.glb")
        os.makedirs(os.path.dirname(out), exist_ok=True)
        bpy.ops.object.select_all(action='SELECT')
        bpy.ops.export_scene.gltf(filepath=out, export_format='GLB')
        ctx.scene.aimcp_chat.add("system", "Exported")
        if ctx.area: ctx.area.tag_redraw(); return {'FINISHED'}

class OP_StopAgent(Operator):
    bl_idname = "aimcp.stop_agent"; bl_label = "Stop Agent"
    def execute(self, ctx):
        # Acceso directo a la variable global de parada
        bsock._stop_agent = True
        ctx.scene.aimcp_waiting = False
        ctx.scene.aimcp_ai_state = "connected"
        ctx.scene.aimcp_status = "DETENIDO POR EL USUARIO"
        if ctx.area: ctx.area.tag_redraw()
        return {'FINISHED'}

class OP_ClearChat(Operator):
    bl_idname = "aimcp.clear_chat"; bl_label = "Clear"
    def execute(self, ctx):
        ctx.scene.aimcp_chat.clear_all()
        bsock._clear_memory_flag = True # SEÑAL PARA EL SERVIDOR
        ctx.scene.aimcp_chat_index = -1
        if ctx.area: ctx.area.tag_redraw()
        return {'FINISHED'}

# ─── Register ───
classes = [
    ChatMsg, ChatData, MCP_UL_Chat, ModelItem, ModelsData,
    OP_Check, OP_Refresh, OP_SelectModel, OP_ApplyModel, OP_ClearSearch,
    OP_Disconnect, OP_Send, OP_Capture, OP_Export, OP_ClearChat, OP_StopAgent,
    PN_PT_Config, PN_PT_Chat,
]

def register():
    for cls in classes: bpy.utils.register_class(cls)
    Scene = bpy.types.Scene
    Scene.aimcp_chat = PointerProperty(type=ChatData)
    Scene.aimcp_input = StringProperty(default="")
    Scene.aimcp_connected = BoolProperty(default=False)
    Scene.aimcp_refreshing = BoolProperty(default=False)
    Scene.aimcp_waiting = BoolProperty(default=False)
    Scene.aimcp_pending_msg_id = StringProperty(default="")
    Scene.aimcp_chat_index = IntProperty(default=0)
    Scene.aimcp_model = StringProperty(default="")
    Scene.aimcp_status = StringProperty(default="")
    Scene.aimcp_models = PointerProperty(type=ModelsData)
    Scene.aimcp_ai_state = StringProperty(default="connected")
    Scene.aimcp_spinner_idx = IntProperty(default=0)
    for pid in PROVIDER_ORDER:
        setattr(Scene, f"aimcp_search_{pid.replace('-','_')}", StringProperty(default=""))
        setattr(Scene, f"aimcp_show_{pid.replace('-','_')}", BoolProperty(default=False))

    # ─── Timers (CRITICAL: must always register) ───
    def delayed_load():
        for s in bpy.data.scenes:
            load_history(s.aimcp_chat)
        # CARGAR MODELO POR DEFECTO AL INICIAR
        try: bpy.ops.aimcp.refresh()
        except: pass
        return None
    bpy.app.timers.register(delayed_load, first_interval=0.5)

    def _redraw_areas():
        for screen in bpy.data.screens:
            for area in screen.areas:
                if area.type in ('VIEW_3D', 'PROPERTIES'):
                    area.tag_redraw()

    # Spinner animation (0.3s)
    def spinner_tick():
        any_waiting = False
        for s in bpy.data.scenes:
            if s.aimcp_waiting:
                s.aimcp_spinner_idx = (s.aimcp_spinner_idx + 1) % len(SPINNER_FRAMES)
                any_waiting = True
        if any_waiting:
            _redraw_areas()
        return 0.1
    bpy.app.timers.register(spinner_tick, first_interval=0.1)

    # Health check (1s) — checks socket + MCP state
    def health_check():
        changed = False
        now = time.time()
        # Auto-reset mcp_connected if no ping in 15s
        if bsock.mcp_connected and now - bsock.mcp_last_ping > 15:
            bsock.mcp_connected = False
        for s in bpy.data.scenes:
            old_state = s.aimcp_ai_state
            old_conn = s.aimcp_connected
            is_connected = bsock._socket_server is not None and bsock._socket_server.running
            s.aimcp_connected = is_connected
            if s.aimcp_waiting:
                s.aimcp_ai_state = "processing"
            elif not is_connected:
                s.aimcp_ai_state = "disconnected"
            elif bsock.mcp_connected:
                s.aimcp_ai_state = "connected"
            else:
                s.aimcp_ai_state = "no_mcp"
            if s.aimcp_ai_state != old_state or s.aimcp_connected != old_conn:
                changed = True
        if changed:
            _redraw_areas()
        return 1.0
    bpy.app.timers.register(health_check, first_interval=0.1)

    # ─── Socket server (replaces HTTP bridge) ───
    try:
        bsock.start_socket_server()
    except:
        print("[blender-mcp] Socket server failed")

def unregister():
    bsock.stop_socket_server()
    for cls in reversed(classes):
        try: bpy.utils.unregister_class(cls)
        except: pass
    attrs = ["aimcp_models", "aimcp_status", "aimcp_model",
             "aimcp_pending_msg_id", "aimcp_chat_index", "aimcp_waiting", "aimcp_refreshing",
             "aimcp_connected", "aimcp_input", "aimcp_chat",
             "aimcp_ai_state", "aimcp_spinner_idx"]
    for pid in PROVIDER_ORDER:
        attrs.append(f"aimcp_search_{pid.replace('-','_')}")
    for a in attrs:
        if hasattr(bpy.types.Scene, a):
            try: delattr(bpy.types.Scene, a)
            except: pass

if __name__ == "__main__":
    register()
